-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2020 at 11:10 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employee_list_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`) VALUES
(1, 'Stracke Group'),
(2, 'Hickle-Reynolds'),
(3, 'Quigley-Purdy'),
(4, 'Pouros-Parker'),
(5, 'Leannon LLC'),
(6, 'D\'Amore-Dare'),
(7, 'Schmitt Ltd'),
(8, 'O\'Reilly-West'),
(9, 'Kris-Lehner'),
(10, 'Thiel Ltd');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`) VALUES
(1, 'Accounting and Finance'),
(2, 'Research and Development'),
(3, 'Purchasing'),
(4, 'Marketing '),
(5, 'Human Resource Management'),
(6, 'Production');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `age` int(255) NOT NULL,
  `company_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `email`, `age`, `company_id`, `department_id`, `created_at`, `updated_at`) VALUES
(1, 'Alwyn Matusson', 'amatusson0@imdb.com', 45, 1, 2, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(2, 'Creight Ferney', 'cferney1@google.com.hk', 28, 6, 5, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(3, 'Aldus Mabb', 'amabb2@businesswire.com', 24, 9, 4, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(4, 'Dewie Nuemann', 'dnuemann3@wix.com', 28, 1, 2, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(5, 'Drusilla Lages', 'dlages4@soundcloud.com', 49, 7, 1, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(6, 'Fremont Gilloran', 'fgilloran5@cam.ac.uk', 43, 8, 6, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(7, 'Koralle Espy', 'kespy6@guardian.co.uk', 33, 7, 2, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(8, 'Raye Edensor', 'redensor7@state.tx.us', 50, 3, 6, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(9, 'Quentin Dumbar', 'qdumbar8@slashdot.org', 49, 5, 1, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(10, 'Jakob Coultish', 'jcoultish9@google.com.hk', 23, 7, 5, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(11, 'Mady Goade', 'mgoadea@archive.org', 24, 5, 4, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(12, 'Martie Escolme', 'mescolmeb@sphinn.com', 44, 3, 2, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(13, 'Jaquelyn Tubble', 'jtubblec@eepurl.com', 33, 1, 1, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(14, 'Joshua Kershow', 'jkershowd@google.cn', 23, 1, 2, '2020-10-21 10:17:24', '2020-10-21 10:17:24'),
(15, 'Cornie Bryan', 'cbryane@phpbb.com', 37, 6, 1, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(16, 'Vitoria Ballin', 'vballinf@dot.gov', 33, 3, 4, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(17, 'Bettine Giorgi', 'bgiorgig@qq.com', 41, 4, 3, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(18, 'Kyle Morford', 'kmorfordh@aol.com', 32, 10, 2, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(19, 'Rodolph Seadon', 'rseadoni@arstechnica.com', 41, 4, 3, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(20, 'Rex Lovel', 'rlovelj@php.net', 33, 2, 1, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(21, 'Justinian Broadberry', 'jbroadberryk@typepad.com', 44, 6, 6, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(22, 'Eldredge Glancey', 'eglanceyl@theglobeandmail.com', 28, 6, 2, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(23, 'Elbert Dunsmore', 'edunsmorem@sbwire.com', 32, 7, 3, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(24, 'Matt Saurat', 'msauratn@columbia.edu', 22, 7, 1, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(25, 'Melly Ramey', 'mrameyo@yahoo.co.jp', 26, 1, 5, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(26, 'Luciano Steptowe', 'lsteptowep@seattletimes.com', 46, 9, 2, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(27, 'Bordie Budden', 'bbuddenq@mapy.cz', 38, 3, 6, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(28, 'Eduino Divill', 'edivillr@biglobe.ne.jp', 48, 6, 6, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(29, 'Emmit Callicott', 'ecallicotts@e-recht24.de', 23, 8, 5, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(30, 'Rosalinde Lelande', 'rlelandet@howstuffworks.com', 46, 2, 4, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(31, 'Chadd Blasik', 'cblasiku@diigo.com', 41, 9, 4, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(32, 'Carolina Andrioni', 'candrioniv@moonfruit.com', 22, 2, 3, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(33, 'Derk Hortop', 'dhortopw@edublogs.org', 32, 2, 6, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(34, 'Alwyn Bardey', 'abardeyx@godaddy.com', 47, 3, 5, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(35, 'Barbabas Ringe', 'bringey@arizona.edu', 48, 2, 6, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(36, 'Larisa Snowden', 'lsnowdenz@archive.org', 25, 6, 3, '2020-10-21 10:17:25', '2020-10-21 10:17:25'),
(37, 'Jarib Corbert', 'jcorbert10@comcast.net', 28, 2, 4, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(38, 'Grier Tigner', 'gtigner11@imageshack.us', 49, 10, 3, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(39, 'Christiana Dumbreck', 'cdumbreck12@unblog.fr', 29, 3, 1, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(40, 'Vito Chantrell', 'vchantrell13@blinklist.com', 30, 7, 5, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(41, 'Son Gleave', 'sgleave14@timesonline.co.uk', 31, 6, 2, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(42, 'Alanna Chill', 'achill15@yale.edu', 38, 4, 1, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(43, 'Burty Persse', 'bpersse16@gmpg.org', 24, 9, 1, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(44, 'Imogen Corrao', 'icorrao17@vimeo.com', 23, 4, 6, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(45, 'Tammy Headon', 'theadon18@usatoday.com', 27, 5, 3, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(46, 'Sena Lucey', 'slucey19@nasa.gov', 37, 9, 5, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(47, 'Adina Adnams', 'aadnams1a@g.co', 70, 3, 6, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(48, 'Timmie Clayworth', 'tclayworth1b@guardian.co.uk', 44, 9, 2, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(49, 'Cristal Marsland', 'cmarsland1c@nifty.com', 39, 4, 1, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(50, 'Tymon Giraldez', 'tgiraldez1d@uol.com.br', 22, 3, 4, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(51, 'Wyn Hirschmann', 'whirschmann1e@google.pl', 40, 5, 5, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(53, 'Audrie Ferryman', 'aferryman1g@cocolog-nifty.com', 48, 1, 5, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(54, 'Emmalyn Figgures', 'efiggures1h@tamu.edu', 25, 7, 6, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(55, 'Arnaldo Izakof', 'aizakof1i@smugmug.com', 48, 5, 2, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(56, 'Brittani Flannigan', 'bflannigan1j@acquirethisname.com', 35, 2, 6, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(57, 'Marwin Bellino', 'mbellino1k@stanford.edu', 40, 10, 6, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(58, 'Felizio Vallerine', 'fvallerine1l@linkedin.com', 41, 8, 2, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(59, 'Boycey Althrop', 'balthrop1m@studiopress.com', 38, 1, 1, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(60, 'Jaclin Hebborne', 'jhebborne1n@cbsnews.com', 46, 1, 1, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(61, 'Petra Stubbes', 'pstubbes1o@yelp.com', 48, 8, 6, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(62, 'Ellie Dahill', 'edahill1p@usgs.gov', 50, 2, 2, '2020-10-21 10:17:26', '2020-10-21 10:17:26'),
(63, 'Minnie de la Tremoille', 'mde1q@ox.ac.uk', 26, 3, 4, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(64, 'Sheba McSwan', 'smcswan1r@reddit.com', 34, 6, 5, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(65, 'Hewet Noell', 'hnoell1s@mac.com', 35, 5, 2, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(66, 'Aldric Scandwright', 'ascandwright1t@reddit.com', 48, 6, 3, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(67, 'Isaac Sorrell', 'isorrell1u@ucoz.com', 41, 6, 1, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(68, 'Verne Giblin', 'vgiblin1v@cloudflare.com', 46, 1, 6, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(69, 'Tarah Benedick', 'tbenedick1w@hibu.com', 26, 1, 1, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(70, 'Ozzy Leech', 'oleech1x@tinypic.com', 24, 10, 5, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(71, 'Bee Grimme', 'bgrimme1y@washington.edu', 46, 8, 3, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(72, 'Taylor Sergison', 'tsergison1z@mozilla.com', 24, 1, 5, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(73, 'Leonore Sommerling', 'lsommerling20@blog.com', 35, 10, 4, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(74, 'Kit Corking', 'kcorking21@gnu.org', 28, 5, 1, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(75, 'Erna O\'Tuohy', 'eotuohy22@yolasite.com', 23, 9, 6, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(76, 'Lorna Durak', 'ldurak23@cornell.edu', 35, 6, 2, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(77, 'Heloise Chaulk', 'hchaulk24@gnu.org', 33, 1, 4, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(78, 'Britney Ivanonko', 'bivanonko25@wikimedia.org', 35, 9, 1, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(79, 'Sophi Pegler', 'spegler26@ocn.ne.jp', 22, 7, 2, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(80, 'Stacee Ensor', 'sensor27@dmoz.org', 31, 2, 1, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(81, 'Taite Jonah', 'tjonah28@histats.com', 40, 1, 2, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(82, 'Ninnetta Lynas', 'nlynas29@stumbleupon.com', 22, 5, 4, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(84, 'Harcourt D\'Antuoni', 'hdantuoni2b@tinypic.com', 39, 1, 4, '2020-10-21 10:17:27', '2020-10-21 10:17:27'),
(85, 'Faunie Pulhoster', 'fpulhoster2c@icq.com', 42, 8, 5, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(86, 'Gianni Stiffell', 'gstiffell2d@wufoo.com', 49, 10, 4, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(87, 'Joshuah Rudgard', 'jrudgard2e@biblegateway.com', 33, 8, 4, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(88, 'Sharona Origin', 'sorigin2f@jiathis.com', 37, 7, 5, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(89, 'Doralyn Stenners', 'dstenners2g@rediff.com', 25, 4, 1, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(90, 'Evonne Windridge', 'ewindridge2h@java.com', 25, 7, 5, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(91, 'Pam Meckiff', 'pmeckiff2i@boston.com', 33, 6, 2, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(92, 'Kaitlyn Fyall', 'kfyall2j@miitbeian.gov.cn', 24, 9, 5, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(93, 'Ber Busain', 'bbusain2k@amazon.com', 49, 2, 1, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(94, 'Gino Keys', 'gkeys2l@google.ru', 27, 9, 3, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(95, 'Orland Elstob', 'oelstob2m@youtube.com', 32, 4, 1, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(96, 'Rosalyn Sanpere', 'rsanpere2n@addthis.com', 31, 7, 1, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(97, 'Valerye Heady', 'vheady2o@nsw.gov.au', 43, 8, 3, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(98, 'Geoffrey Drinkall', 'gdrinkall2p@census.gov', 34, 3, 5, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(99, 'Hamnet Arnison', 'harnison2q@bravesites.com', 23, 8, 3, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(100, 'Sherrie Rosten', 'srosten2r@berkeley.edu', 38, 6, 5, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(101, 'Vladamir Allward', 'vallward2s@reddit.com', 31, 5, 5, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(102, 'Dorris Klimt', 'dklimt2t@washingtonpost.com', 41, 7, 5, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(103, 'Shantee Barnby', 'sbarnby2u@independent.co.uk', 40, 10, 2, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(104, 'Delmor Towers', 'dtowers2v@delicious.com', 42, 6, 3, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(105, 'Selig Jarrelt', 'sjarrelt2w@reverbnation.com', 48, 5, 5, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(106, 'Bent Rea', 'brea2x@slashdot.org', 35, 8, 1, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(107, 'Prudi Dorow', 'pdorow2y@toplist.cz', 48, 3, 3, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(108, 'Tasia Bonnick', 'tbonnick2z@adobe.com', 37, 7, 2, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(109, 'Tally Ringrose', 'tringrose30@php.net', 29, 9, 1, '2020-10-21 10:17:28', '2020-10-21 10:17:28'),
(110, 'Kayley Bollini', 'kbollini31@guardian.co.uk', 23, 6, 2, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(111, 'Wilton De Freyne', 'wde32@jugem.jp', 27, 5, 5, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(112, 'Gabbie Landeaux', 'glandeaux33@unicef.org', 22, 4, 3, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(113, 'Cindy Hulance', 'chulance34@paypal.com', 29, 2, 2, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(114, 'Hubey Tarplee', 'htarplee35@etsy.com', 41, 10, 4, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(115, 'Giovanni Wadham', 'gwadham36@wp.com', 39, 6, 2, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(116, 'Angie Dabney', 'adabney37@nasa.gov', 36, 2, 2, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(117, 'Donovan Belone', 'dbelone38@symantec.com', 38, 1, 1, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(118, 'Eran Cadman', 'ecadman39@cdbaby.com', 45, 3, 6, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(119, 'Eileen Wolverson', 'ewolverson3a@goo.gl', 34, 2, 2, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(120, 'Linet Itzhayek', 'litzhayek3b@whitehouse.gov', 36, 7, 5, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(121, 'Cyrillus Smurthwaite', 'csmurthwaite3c@army.mil', 47, 1, 2, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(122, 'Elaine Hierro', 'ehierro3d@google.co.jp', 46, 5, 5, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(123, 'Joete Witherop', 'jwitherop3e@topsy.com', 38, 9, 2, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(124, 'Shane Horlick', 'shorlick3f@amazonaws.com', 48, 2, 6, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(125, 'Dean M\'Quharg', 'dmquharg3g@miibeian.gov.cn', 45, 7, 1, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(126, 'Cyb Evemy', 'cevemy3h@wp.com', 49, 7, 4, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(127, 'Hayes Mogenot', 'hmogenot3i@plala.or.jp', 22, 7, 1, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(128, 'Ariel Mousdall', 'amousdall3j@bravesites.com', 42, 1, 1, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(129, 'Fitzgerald Heinel', 'fheinel3k@sun.com', 22, 6, 4, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(130, 'Odelle Vescovini', 'ovescovini3l@odnoklassniki.ru', 32, 5, 4, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(131, 'Shermy Kilgannon', 'skilgannon3m@rambler.ru', 23, 1, 6, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(132, 'Mitzi Sutliff', 'msutliff3n@howstuffworks.com', 41, 9, 6, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(133, 'Barbra Wikey', 'bwikey3o@wiley.com', 32, 2, 2, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(134, 'Malvin Sleet', 'msleet3p@twitpic.com', 39, 5, 5, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(135, 'Guilbert Knok', 'gknok3q@dion.ne.jp', 31, 4, 2, '2020-10-21 10:17:29', '2020-10-21 10:17:29'),
(136, 'Dominic McCorkell', 'dmccorkell3r@privacy.gov.au', 46, 3, 5, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(137, 'Blondie Fitter', 'bfitter3s@shareasale.com', 46, 5, 2, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(138, 'Marylinda Stubbington', 'mstubbington3t@economist.com', 27, 6, 5, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(139, 'Ainslie Balogh', 'abalogh3u@gmpg.org', 29, 8, 6, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(140, 'Cherie Kitcat', 'ckitcat3v@weibo.com', 47, 10, 4, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(141, 'Ches McLukie', 'cmclukie3w@marketwatch.com', 30, 2, 6, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(142, 'Rosemary Selly', 'rselly3x@netvibes.com', 36, 10, 6, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(143, 'Lyle Ferrar', 'lferrar3y@whitehouse.gov', 35, 3, 4, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(144, 'Alexandros Dowty', 'adowty3z@ebay.com', 29, 7, 1, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(145, 'Philbert Orwin', 'porwin40@reuters.com', 29, 9, 5, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(146, 'Skipton Chue', 'schue41@so-net.ne.jp', 33, 6, 4, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(147, 'Davon Robic', 'drobic42@about.com', 36, 7, 4, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(148, 'Meta Kirckman', 'mkirckman43@mac.com', 25, 8, 3, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(149, 'Jaquenetta Mendel', 'jmendel44@delicious.com', 46, 1, 5, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(150, 'Jack Brecher', 'jbrecher45@globo.com', 33, 8, 1, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(151, 'Markos Yannoni', 'myannoni46@weibo.com', 39, 2, 1, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(152, 'Joyous Filgate', 'jfilgate47@cyberchimps.com', 38, 9, 5, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(153, 'Myrilla Derisly', 'mderisly48@sun.com', 46, 9, 1, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(154, 'Dolli Grayley', 'dgrayley49@slideshare.net', 49, 8, 3, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(155, 'Maribelle Rosiello', 'mrosiello4a@diigo.com', 36, 2, 6, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(156, 'Sloan Climer', 'sclimer4b@state.tx.us', 44, 9, 2, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(157, 'Barbabra Gaynsford', 'bgaynsford4c@tripadvisor.com', 32, 7, 1, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(158, 'Erminie Prestage', 'eprestage4d@woothemes.com', 31, 2, 5, '2020-10-21 10:17:30', '2020-10-21 10:17:30'),
(159, 'Tiena Spearing', 'tspearing4e@histats.com', 33, 8, 3, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(160, 'Kristyn Abram', 'kabram4f@hostgator.com', 43, 8, 2, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(161, 'Sharia Evenden', 'sevenden4g@businessinsider.com', 43, 2, 5, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(162, 'Haze Wolfarth', 'hwolfarth4h@comcast.net', 40, 6, 5, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(163, 'Reinald Burtonwood', 'rburtonwood4i@spiegel.de', 50, 7, 2, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(164, 'Gay Lanmeid', 'glanmeid4j@guardian.co.uk', 37, 6, 5, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(165, 'Joya Thirkettle', 'jthirkettle4k@stumbleupon.com', 50, 7, 1, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(166, 'Magdaia Toombes', 'mtoombes4l@gravatar.com', 31, 8, 3, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(167, 'Jeramie Bortolini', 'jbortolini4m@eepurl.com', 48, 5, 1, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(168, 'Erin Marrable', 'emarrable4n@europa.eu', 41, 1, 2, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(169, 'Nisse Brotherwood', 'nbrotherwood4o@slideshare.net', 47, 7, 3, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(170, 'Lorena Taylot', 'ltaylot4p@icio.us', 39, 7, 6, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(171, 'Alyssa Chicotti', 'achicotti4q@smugmug.com', 38, 4, 6, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(172, 'Rhett Kellough', 'rkellough4r@amazon.de', 27, 2, 3, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(173, 'Julianne Verbruggen', 'jverbruggen4s@senate.gov', 50, 3, 4, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(174, 'Trudey Melody', 'tmelody4t@bloglines.com', 31, 1, 4, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(175, 'Quincy Ordish', 'qordish4u@cafepress.com', 24, 1, 4, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(176, 'Blanch Jostan', 'bjostan4v@oracle.com', 49, 10, 2, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(177, 'Wyatan Tabb', 'wtabb4w@nsw.gov.au', 42, 8, 1, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(178, 'Ollie Menary', 'omenary4x@tmall.com', 26, 5, 1, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(179, 'Guthrey Sell', 'gsell4y@amazonaws.com', 28, 1, 3, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(180, 'Leonelle Harrington', 'lharrington4z@eepurl.com', 48, 5, 5, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(181, 'Kimble D\'orsay', 'kdorsay50@theglobeandmail.com', 37, 3, 6, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(182, 'Archibald Ingerson', 'aingerson51@ebay.co.uk', 47, 6, 5, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(183, 'Den Capper', 'dcapper52@gnu.org', 35, 9, 6, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(184, 'Lona Dana', 'ldana53@sciencedirect.com', 37, 1, 5, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(185, 'Bernice Piercey', 'bpiercey54@php.net', 36, 1, 4, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(186, 'Izaak Atger', 'iatger55@bravesites.com', 36, 7, 2, '2020-10-21 10:17:31', '2020-10-21 10:17:31'),
(187, 'Bard Oakman', 'boakman56@cbc.ca', 34, 10, 3, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(188, 'Annemarie Newling', 'anewling57@google.it', 50, 9, 4, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(189, 'Kaia Larcher', 'klarcher58@wiley.com', 39, 1, 5, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(190, 'Carlin Hatherleigh', 'chatherleigh59@ebay.co.uk', 37, 1, 4, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(191, 'Emilio Spileman', 'espileman5a@sakura.ne.jp', 28, 1, 1, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(192, 'Dynah Trowsdall', 'dtrowsdall5b@usatoday.com', 36, 9, 1, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(193, 'Stacee Kraft', 'skraft5c@bandcamp.com', 33, 3, 3, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(194, 'Barbabra Pruckner', 'bpruckner5d@fda.gov', 45, 4, 1, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(195, 'Hollyanne Bacchus', 'hbacchus5e@youtube.com', 47, 4, 6, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(196, 'Pammi Vardey', 'pvardey5f@exblog.jp', 42, 7, 2, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(197, 'Clea Stowgill', 'cstowgill5g@cafepress.com', 23, 3, 5, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(198, 'John McGaraghan', 'jmcgaraghan5h@sina.com.cn', 28, 5, 3, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(199, 'Scotty MacAughtrie', 'smacaughtrie5i@creativecommons.org', 39, 7, 6, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(200, 'Cirillo Cuttle', 'ccuttle5j@homestead.com', 23, 4, 5, '2020-10-21 10:17:32', '2020-10-21 10:17:32'),
(201, 'employee1', 'employee1@gmail.com', 25, 10, 6, '2020-10-21 18:22:15', '2020-10-21 18:22:15'),
(202, 'employee2', 'employee2@gmail.com', 25, 8, 2, '2020-10-21 18:22:57', '2020-10-21 18:22:57'),
(207, 'employee3', 'employee3@gmail.com', 26, 9, 4, '2020-10-21 18:30:59', '2020-10-21 18:30:59'),
(208, 'employee4', 'employee4@gmail.com', 27, 7, 3, '2020-10-21 18:37:53', '2020-10-21 18:37:53'),
(211, 'Aung Aung', 'aung@gmail.com', 25, 7, 3, '2020-10-22 08:59:11', '2020-10-22 08:59:11'),
(212, 'Tun Tun', 'tuntun@gmail.com', 26, 8, 4, '2020-10-22 08:59:48', '2020-10-22 08:59:48'),
(213, 'AyeAye', 'ayeaye@gmail.com', 28, 5, 3, '2020-10-22 09:04:40', '2020-10-22 09:04:40'),
(214, 'zawzaw', 'zaw@gmail.com', 29, 5, 2, '2020-10-22 09:05:50', '2020-10-22 09:05:50');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$pjCEzbuUZP7LD/iSalCpq.66aI3eS/WlRhIM/aUixpnbfO/HE.Cxi', 1, '2020-10-21 11:53:52', '2020-10-21 11:53:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=215;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
